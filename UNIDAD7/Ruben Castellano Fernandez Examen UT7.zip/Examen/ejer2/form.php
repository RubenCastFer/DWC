<?php
// Rubén Castellano Fernández
//recojo con post
$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
$apellido2 = $_POST["apellido2"];
$ciudad = $_POST["ciudad"];

//muestro
echo  $nombre." ".$apellido." ".$apellido2." ".$ciudad; 
?>